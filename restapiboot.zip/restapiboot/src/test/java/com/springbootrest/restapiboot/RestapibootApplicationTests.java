package com.springbootrest.restapiboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestapibootApplicationTests {

	@Test
	void contextLoads() {
	}

}
