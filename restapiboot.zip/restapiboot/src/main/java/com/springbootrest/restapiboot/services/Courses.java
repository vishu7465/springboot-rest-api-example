package com.springbootrest.restapiboot.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.springbootrest.restapiboot.bean.course;
@Service
public class Courses implements courseserviceimpl{

	List<course> list;
	
	public Courses() {

		 list=new ArrayList<>();
		
		list.add(new course(12,"java","this is core java course"));
		list.add(new course(13,"php","this is php course"));
		list.add(new course(14,"python","this is python course"));
		
		
	}

	
	public List<course> allcourses() {
		
		
		return list;
	}


	
	@Override
	public course addcourse(course cs) {
		
		list.add(cs);
		
		return cs;
		
			}


	@Override
	public course deletecourse(long id) {
	
		course c=null;
		for(course cs:list) {
			
			if(cs.getId()==id) {
				
				list.remove(cs);
				c=cs;
				break;
			}
		}
		return c;
		
		
	}
	
}
