package com.springbootrest.restapiboot.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springbootrest.restapiboot.bean.course;
import com.springbootrest.restapiboot.services.Courses;
import com.springbootrest.restapiboot.services.courseserviceimpl;

@RestController
public class Mycontroller {

	@Autowired
	private courseserviceimpl cs;
	
	@GetMapping("/home")
	public String home() {
		
		return "this is my home";
	}
	
	@GetMapping("/courses")
	public 	List<course> allcourse() {
		
		return this.cs.allcourses();
	}
	@PostMapping("/courses")
	public course addcourse(@RequestBody course cs) {
		
		
		return this.cs.addcourse(cs);
		
	}
	
	@PostMapping("/courses/{id}")
	public course delete(@PathVariable String id) {
		
		
		return this.cs.deletecourse(Integer.parseInt(id));
		
	}
	
}
