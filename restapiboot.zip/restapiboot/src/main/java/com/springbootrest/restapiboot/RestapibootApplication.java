package com.springbootrest.restapiboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestapibootApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestapibootApplication.class, args);
	}

}
