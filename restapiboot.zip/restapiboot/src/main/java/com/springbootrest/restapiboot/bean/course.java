package com.springbootrest.restapiboot.bean;

public class course {

	private int id;
	private String coursename;
	private String coursedesc;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public String getCoursedesc() {
		return coursedesc;
	}
	public void setCoursedesc(String coursedesc) {
		this.coursedesc = coursedesc;
	}
	public course(int id, String coursename, String coursedesc) {
		super();
		this.id = id;
		this.coursename = coursename;
		this.coursedesc = coursedesc;
	}
	@Override
	public String toString() {
		return "course [id=" + id + ", coursename=" + coursename + ", coursedesc=" + coursedesc + "]";
	}
	
	
	
}
