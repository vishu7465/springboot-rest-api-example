package com.springbootrest.restapiboot.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.springbootrest.restapiboot.bean.course;

public interface courseserviceimpl {

	
	public List<course> allcourses();
	
	

	public course addcourse(course cs);
	
	public course deletecourse(long id);
}
